package vehicule;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class Passerelle {

    private static Connection conn = null;

    // Getter pour le Main
    public static Connection getConn() {
        return conn;
    }

    // 1. Connexion à la base de données
    public static void connecter() {
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://192.168.1.245:5432/slam2026APvechicule_Louise_Thymeo";
            String user = "lemay";
            String password = "lemay";

            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion a PostgreSQL reussie.");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver non trouve : " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Erreur de connexion : " + e.getMessage());
        }
    }

    // 2. Enregistrer une nouvelle demande
    public static boolean enregistrerDemande(Demande d) {
        // Cette requête utilise maintenant les colonnes que vous venez d'ajouter
        String sql = "INSERT INTO demande (matricule, no_type, date_debut, duree, etat, datereserv) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, Integer.parseInt(d.getMatricule())); // matricule (integer)
            pst.setInt(2, d.getNoType());                      // no_type (integer)
            pst.setDate(3, java.sql.Date.valueOf(d.getDateDebut()));
            pst.setInt(4, d.getDuree());                       // duree (integer)
            pst.setString(5, d.getEtat());                     // etat (varchar)
            pst.setDate(6, java.sql.Date.valueOf(java.time.LocalDate.now()));

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur SQL : " + e.getMessage());
            return false;
        }
    }

    public static List<Demande> getDemandesParEtat(String etatRecherche) {
        List<Demande> liste = new ArrayList<>();
        String sql = "SELECT * FROM demande WHERE etat = ?";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, etatRecherche);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Demande d = new Demande(
                        rs.getDate("date_debut").toLocalDate(),
                        rs.getInt("duree"),
                        String.valueOf(rs.getInt("matricule")),
                        rs.getInt("no_type")
                );
                d.setNumero(rs.getInt("no_demande"));
                d.setEtat(rs.getString("etat"));
                d.setImmat(rs.getString("immatriculation"));
                liste.add(d);
            }
        } catch (SQLException e) {
            System.err.println("Erreur de lecture : " + e.getMessage());
        }
        return liste;
    }

    // 4. Valider une demande (Mode Gestionnaire)
    public static boolean validerDemande(int numDemande, String immat) {
        // CORRECTION : numero -> no_demande | immat -> immatriculation
        String sql = "UPDATE demande SET etat = 'validee', immatriculation = ? WHERE no_demande = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, immat);
            pst.setInt(2, numDemande);

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la validation : " + e.getMessage());
            return false;
        }
    }

    // 5. Authentification
    public static boolean verifierMatricule(String matricule) {
        String sql = "SELECT COUNT(*) FROM personne WHERE matricule = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, Integer.parseInt(matricule));
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            System.err.println("Erreur verification matricule : " + e.getMessage());
        }
        return false;
    }

    // 6. Lister les véhicules disponibles pour un type
    public static List<String> getVehiculesDisponibles(int idType) {
        List<String> vehicules = new ArrayList<>();
        // CORRECTION : immat -> immatriculation | notype -> no_type
        String sql = "SELECT immatriculation, modele FROM vehicule WHERE no_type = ? "
                + "AND immatriculation NOT IN (SELECT immatriculation FROM demande WHERE etat = 'validee' AND immatriculation IS NOT NULL)";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, idType);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                vehicules.add(rs.getString("immatriculation") + " (" + rs.getString("modele") + ")");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vehicules;
    }
}

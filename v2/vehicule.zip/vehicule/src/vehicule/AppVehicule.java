package vehicule;


import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class AppVehicule {

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Passerelle.connecter();

        String matriculeConnecte = "";
        boolean estConnecte = false;

        System.out.println("=== CONNEXION AU SYSTEME ===");

        // Boucle de connexion
        while (!estConnecte) {
            System.out.print("Veuillez saisir votre matricule agent : ");
            matriculeConnecte = scanner.nextLine();

            if (Passerelle.verifierMatricule(matriculeConnecte)) {
                System.out.println("Connexion reussie ! Bienvenue agent " + matriculeConnecte);
                estConnecte = true;
            } else {
                System.out.println("Erreur : Matricule inconnu. Veuillez reessayer.");
            }
        }

        int choix = 0;
        System.out.println("******************************************");
        System.out.println("* GESTION DES VEHICULES DE L'HOPITAL   *");
        System.out.println("******************************************");

        do {
            afficherMenu();
            try {
                choix = Integer.parseInt(scanner.nextLine());

                switch (choix) {
                    case 1:
                        menuNouvelleDemande();
                        break;
                    case 2:
                        menuListeAttente();
                        break;
                    case 3:
                        menuValiderDemande();
                        break;
                    case 4:
                        menuListeParEtat();
                        break;
                    case 0:
                        System.out.println("Fermeture de l'application...");
                        break;
                    default:
                        System.out.println("Option inconnue, réessayez.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erreur : Veuillez saisir un nombre valide.");
            }
        } while (choix != 0);
    }

    private static void afficherMenu() {
        System.out.println("\n--- MENU PRINCIPAL ---");
        System.out.println("1. [AGENT] Faire une demande de reservation");
        System.out.println("2. [GESTIONNAIRE] Voir les demandes en attente");
        System.out.println("3. [GESTIONNAIRE] Valider une demande (Affecter vehicule)");
        System.out.println("4. [CONSULTATION] Lister les demandes par etat");
        System.out.println("0. Quitter");
        System.out.print("Votre choix : ");
    }

    private static void menuNouvelleDemande() {
        try {
            System.out.println("\n-- Nouvelle Demande --");
            System.out.print("Matricule de l'employé : ");
            String mat = scanner.nextLine();

            System.out.print("Date de début (AAAA-MM-JJ) : ");
            String dateSaisie = scanner.nextLine();
            LocalDate debut = LocalDate.parse(dateSaisie);

            System.out.print("Durée du besoin (en jours) : ");
            int duree = Integer.parseInt(scanner.nextLine());

            System.out.print("ID du type de véhicule (1: Citadine, 2: Utilitaire, 3: SAMU) : ");
            int type = Integer.parseInt(scanner.nextLine());

            Demande d = new Demande(debut, duree, mat, type);
            if (Passerelle.enregistrerDemande(d)) {
                System.out.println("=> Succès : Demande enregistrée sous l'état 'demandee'.");
            } else {
                System.out.println("=> Erreur lors de l'enregistrement en base de données.");
            }
        } catch (DateTimeParseException e) {
            System.out.println("Format de date invalide.");
        } catch (Exception e) {
            System.out.println("Erreur de saisie : " + e.getMessage());
        }
    }

    private static void menuListeAttente() {
        System.out.println("\n-- Demandes en attente de validation --");
        List<Demande> attentes = Passerelle.getDemandesParEtat("demandee");
        if (attentes.isEmpty()) {
            System.out.println("Aucune demande en attente.");
        } else {
            for (Demande d : attentes) {
                System.out.println(d.toString());
            }
        }
    }

    private static void menuValiderDemande() {
        System.out.print("\nNuméro de la demande à valider : ");
        int idDemande = Integer.parseInt(scanner.nextLine());

        // On pourrait ici appeler une méthode pour lister les véhicules libres
        System.out.print("Immatriculation du véhicule à affecter : ");
        String immat = scanner.nextLine();

        if (Passerelle.validerDemande(idDemande, immat)) {
            System.out.println("=> Succès : Demande validée.");
        } else {
            System.out.println("=> Échec : Vérifiez le numéro de demande ou l'immatriculation.");
        }
    }

    private static void menuListeParEtat() {
        System.out.print("Entrez l'état souhaité (demandee, validee, terminee, annulee_demandeur) : ");
        String etat = scanner.nextLine();
        List<Demande> liste = Passerelle.getDemandesParEtat(etat);
        for (Demande d : liste) {
            System.out.println(d.toString());
        }
    }
}

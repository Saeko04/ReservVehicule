package vehicule;

import java.time.LocalDate;

public class Demande {
    private int numero;
    private LocalDate dateReserv;
    private LocalDate dateDebut;
    private int duree;
    private LocalDate dateRetourEffectif;
    private String etat;
    private String matricule;
    private int noType;
    private String immat;

    // Constructeur pour une nouvelle demande (utilisé dans le Main)
    public Demande(LocalDate dateDebut, int duree, String matricule, int noType) {
        this.dateDebut = dateDebut;
        this.duree = duree;
        this.matricule = matricule;
        this.noType = noType;
        this.etat = "demandee";
        this.dateReserv = LocalDate.now();
    }

    // --- GETTERS (Indispensables pour que la Passerelle puisse LIRE les données) ---
    
    public int getNumero() { return numero; }
    
    public LocalDate getDateReserv() { return dateReserv; }
    
    public LocalDate getDateDebut() { return dateDebut; }
    
    public int getDuree() { return duree; }
    
    public LocalDate getDateRetourEffectif() { return dateRetourEffectif; }
    
    public String getEtat() { return etat; }
    
    public String getMatricule() { return matricule; }
    
    public int getNoType() { return noType; }
    
    public String getImmat() { return immat; }

    // --- SETTERS (Indispensables pour que la Passerelle puisse MODIFIER l'objet) ---
    
    public void setNumero(int numero) { this.numero = numero; }
    
    public void setEtat(String etat) { this.etat = etat; }
    
    public void setImmat(String immat) { this.immat = immat; }
    
    public void setDateRetourEffectif(LocalDate date) { this.dateRetourEffectif = date; }

    @Override
    public String toString() {
        return "Demande n=" + numero + " [" + etat.toUpperCase() + "]" +
               "\n   - Date debut : " + dateDebut + " (Duree : " + duree + " jours)" +
               "\n   - Demandeur  : " + matricule + 
               "\n   - Vehicule   : " + (immat != null ? immat : "Non affecte") +
               "\n---------------------------------------------";
    }
}
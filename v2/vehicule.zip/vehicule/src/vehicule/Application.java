package vehicule;

import java.util.Scanner;
import java.time.LocalDate;

public class Application {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Passerelle.connecter(); // Connexion à Postgres au démarrage
        int choix = 0;

        System.out.println("=== SYSTEME DE RESERVATION HOPITAL ===");

        do {
            System.out.println("\n1. Creer une demande de vehicule");
            System.out.println("2. Lister les demandes en attente (Gestionnaire)");
            System.out.println("3. Valider une demande (Affecter vehicule)");
            System.out.println("4. Quitter");
            System.out.print("Votre choix : ");
            
            choix = scanner.nextInt();
            scanner.nextLine(); // Consommer le retour ligne

            switch (choix) {
                case 1: menuCreerDemande(); break;
                case 2: menuListerDemandes(); break;
                case 3: menuValiderDemande(); break;
                case 4: System.out.println("Au revoir !"); break;
                default: System.out.println("Choix invalide.");
            }
        } while (choix != 4);
    }

    private static void menuCreerDemande() {
        System.out.print("Votre matricule : ");
        String mat = scanner.nextLine();
        System.out.print("Date de debut (AAAA-MM-JJ) : ");
        LocalDate debut = LocalDate.parse(scanner.nextLine());
        System.out.print("Duree (jours) : ");
        int duree = scanner.nextInt();
        System.out.print("ID Type de vehicule (1: Citadine, 2: Utilitaire...) : ");
        int type = scanner.nextInt();

        Demande d = new Demande(debut, duree, mat, type);
        if (Passerelle.enregistrerDemande(d)) {
            System.out.println("Demande enregistree avec succes !");
        }
    }

    private static void menuListerDemandes() {
        System.out.println("--- Demandes en attente de validation ---");
        for (Demande d : Passerelle.getDemandesParEtat("demandee")) {
            System.out.println(d);
        }
    }

    private static void menuValiderDemande() {
        System.out.print("Numero de la demande à valider : ");
        int num = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Immatriculation du vehicule affecte : ");
        String immat = scanner.nextLine();

        Passerelle.validerDemande(num, immat);
        System.out.println("Demande validee et vehicule affecte.");
    }
}